Supplementary Code and Data for Manuscript:
A multi-omics study unravels the mechanism of water pollutants in gastric cancer: Integrating network toxicology, machine learning, and tumor microenvironment remodeling

Journal: Toxicology Research
Manuscript ID: TOXRES-2025-544

Overview
This repository contains all necessary scripts and processed data to fully reproduce the machine learning-based identification of key targets (EGFR, MMP9, and CXCR4) as described in the above-referenced manuscript. The materials are provided to ensure complete transparency, reproducibility, and to address specific reviewer comments regarding methodological rigor.

Repository Structure：
.
├── Analysis_Scripts/
│   └── machine_learning.R         # Main R script implementing LASSO, SVM, and Random Forest
├── Processed_Data/
│   ├── group_GSE54129.csv         # Sample phenotype (Normal vs. Tumor)
│   ├── GSE54129_expr_data_normalized.csv  # Normalized expression matrix (genes × samples)
│   └── Targets.txt                # List of 8 candidate genes for ML feature selection
├── README.txt                     # This file
└── sessionInfo.txt                # R session information with package versions

File Descriptions

1. Analysis_Scripts/machine_learning.R
This is the primary analysis script that performs the following:
Data loading and preprocessing from the Processed_Data/ folder.
Machine learning modeling using three distinct algorithms:
LASSO Regression (glmnet): 10‑fold cross‑validation for feature selection.
Support Vector Machine (SVM) (e1071): Linear kernel with 10‑fold cross‑validation.
Random Forest (RF) (randomForest): 100 trees, mean decrease in accuracy for feature importance.
Performance evaluation: Calculates accuracy, sensitivity, and specificity for each algorithm via 10‑fold cross‑validation.
Consensus feature selection: Identifies genes selected by all three methods (EGFR, MMP9, CXCR4).

Output generation:
Supplementary_Table_S2_Machine_Learning_Performance.csv: Summary of performance metrics (mean ± SD).
Various CSV files with detailed cross‑validation results and selected genes.

2. Processed_Data/ Folder
group_GSE54129.csv: A two‑column file (sample ID, group) where group is either “Normal” or “Tumor”. Corresponds to the 132 samples (111 tumor, 21 normal) from the GSE54129 dataset.
GSE54129_expr_data_normalized.csv: Normalized gene expression matrix (rows = genes, columns = samples). This matrix is already log‑transformed and normalized, ready for machine learning input.
Targets.txt: A plain text file listing the 8 candidate gene symbols that were carried forward from the network toxicology analysis:
PTGS2, EGFR, TP53, CASP3, MMP9, PPARG, CXCR4, IGF1

System Requirements & Dependencies
R version: ≥ 4.2.0 (recommended)
Required R packages (exact versions are recorded in sessionInfo.txt):
glmnet (for LASSO)
randomForest (for Random Forest)
e1071 (for SVM)
pROC (for ROC/AUC calculations)
tidyverse, ggplot2, caret (for data handling and visualization)

Step‑by‑Step Reproduction Instructions
1、Download the repository (or clone it via Git) to your local machine.
2、Open R/RStudio and set the working directory to the folder that contains both Analysis_Scripts and Processed_Data.
3、Run the main script:source("Analysis_Scripts/machine_learning.R")
Note: The script expects the data files to be located in the Processed_Data/ subdirectory. No manual path adjustments are needed if the folder structure is preserved.
4、Output files will be generated in the current working directory. Key outputs include:
Supplementary_Table_S2_Machine_Learning_Performance.csv
randomforest_cv_details.csv, svm_cv_details.csv, lasso_cv_details.csv
common_selected_genes.csv (consensus gene list)

Contact & Support
For questions regarding the code, data, or reproducibility, please contact the corresponding author:
Name: [CHEN Bang-sheng]
Email: [cbs113@126.com]

License & Citation
This supplementary material is provided under a Creative Commons Attribution 4.0 International (CC BY 4.0) license. You are free to use and adapt the code for any purpose, provided that appropriate credit is given to the original authors. If you use this code or data in your work, please cite the associated manuscript.